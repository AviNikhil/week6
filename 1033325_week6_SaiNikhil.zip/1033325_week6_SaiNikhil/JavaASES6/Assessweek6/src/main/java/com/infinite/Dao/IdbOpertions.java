package com.infinite.Dao;

import java.util.List;

import com.infinite.pojo.Product;

public interface IdbOpertions {
	
	public void insertRecord(String Productname,int Amount,int Quantity,int totalAmount); 
	//Abstract insertrecord method
	   public List<Product> displayRecords();
	   //Abstract displayrecord method
	    public void deleteAllRecords();
	    //Abstract delete method

}
