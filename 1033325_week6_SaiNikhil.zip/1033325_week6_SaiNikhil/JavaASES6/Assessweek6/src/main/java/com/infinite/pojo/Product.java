package com.infinite.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author sainikhilk
 * Implementation of Spring mvc with hibernate
 */
@Entity(name="Product")
public class Product {
	
	@Id
	@Column(name = "Product_Id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "Product_Name")
	private String Productname;
	
	@Column(name = "Amount")
	private int Amount;
	
	@Column(name = "Quantity")
	private int Quantity;
	
	@Column(name = "Total_Amount")
	private int TotalAmount;
	
	public Product() {

		// Constructor
	}

 

	public Product(int id,String Productname,int Amount,int Quantity,int TotalAmount) {
		this.id = id;
		this.Productname = Productname; //Constructor
		this.Amount = Amount;
		this.Quantity = Quantity;
		this.TotalAmount = TotalAmount;
	}



	public int getId() { 
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getProductname() {
		return Productname;
	}



	public void setProductname(String productname) {
		Productname = productname;
	}



	public int getAmount() {
		return Amount;
	}



	public void setAmount(int amount) {
		Amount = amount;
	}



	public int getQuantity() {
		return Quantity;
	}



	public void setQuantity(int quantity) {
		Quantity = quantity;
	}



	public int getTotalAmount() {
		return TotalAmount;
	}



	public void setTotalAmount(int totalAmount) {
		TotalAmount = totalAmount;
	}
	
	

}
