package com.infinite.DaoImpl;

import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.infinite.Dao.IdbOpertions;
import com.infinite.helper.DaoHelper;
import com.infinite.pojo.Product;

public class DbOperationImpl implements IdbOpertions {
	private static final Logger logger = Logger.getLogger(DbOperationImpl.class); //logger
	Session sessionObj = null; //declaring session object
	SessionFactory sessionFactoryObj;
	@Override
	public void insertRecord(String Productname,int Amount,int Quantity,int totalAmount) {
		// TODO Auto-generated method stub

		
	}

	@Override
	public List<Product> displayRecords() {
		// TODO Auto-generated method stub
		List<Product> ls = null;
		String msg = null; //declaring msg
		try {
			BasicConfigurator.configure();
		    Session sessionObj = DaoHelper.buildSessionFactory().openSession();
			Transaction tx = sessionObj.beginTransaction(); //start of transaction
			Query q = sessionObj.createQuery("from Product"); //query creation
			ls = q.list();
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			// Close hibernate session.
			//sessionObj.close();
		}
		return ls;
	}

	@Override
	public void deleteAllRecords() {
		// TODO Auto-generated method stub
		sessionObj = DaoHelper.buildSessionFactory().openSession();
		sessionObj.beginTransaction();
		try{
			sessionObj = DaoHelper.buildSessionFactory().openSession();
			Transaction tx = sessionObj.beginTransaction();
			//Student sd = new Student();
			Query q = sessionObj.createQuery("DELETE FROM Product"); //delete record from Product 
			q.executeUpdate();
			//sessionObj.save(sd);
			tx.commit();
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				sessionObj.close();
			}
		
	}

	
}
