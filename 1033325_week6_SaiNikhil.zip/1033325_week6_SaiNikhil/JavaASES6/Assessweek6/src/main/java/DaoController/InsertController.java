package DaoController;

public class InsertController {

}
