package DaoController;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.DaoImpl.DbOperationImpl;
import com.infinite.pojo.Product;


@Controller
public class DisplayController {
	
	@RequestMapping(value = "/display", method = RequestMethod.POST)
	public String display(HttpServletRequest request, HttpServletResponse response, Model m) {
		List<Product> ls = null;
		String msg = null;
		DbOperationImpl imp= new DbOperationImpl();
		m.addAttribute("msg", ls);
		return "main";
	}
}
